包含您所有Anki数据的文件夹只存放在单一位置
以便备份。若需Anki使用其他位置，
请看：

http://ankisrs.net/docs/manual.html#startupopts
